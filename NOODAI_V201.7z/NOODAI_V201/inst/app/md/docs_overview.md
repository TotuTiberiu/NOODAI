The NOODAI algorithm allows the collective analysis of multiple omics datasets by integrating them into a unified framework. The pipeline starts from lists of upregulated (or downregulated) proteins, genes, and/or small molecules extracted from different omics analyses, organized in separate Excel tables containing multiple sheets corresponding to different comparisons of interest (contrasts). 

<div style="padding: 15px; border: 1px solid transparent; border-color: transparent; margin-bottom: 20px; border-radius: 4px; color: #a94442; background-color: #f2dede; border-color: #ebccd1;">
<strong>Important!</strong> To use this platform, you should have available at least one list of upregulated or downregulated omics data comparing a condition to another (or data that is conceptually similar).
</div>

For each contrast, the algorithm is organized into 4 analysis segments as follows:

- **Segment I:** all proteins, genes, and/or small molecules from different omics analyses are merged into a unified interaction network using filtered knowledge available in STRING, BioGrid, and IntAct databases. After the network is built, NOODAI computes a number of centrality metrics for each node (i.e. proteins) while putting especial interest in the current-flow betweenness centrality. These centrality scores provide a metric of the importance of each node in the context of the overall network.
- **Segment II:** the full-size network is decomposed into subnetworks (also known as modules) using the MONET decomposition tool. In theory, each module is expected to be related to a specific biological function. Such expectation can be checked by evaluating how well the members of the subnetwork associate with a particular signaling pathway.
- **Segment III:** the associated signaling pathways are extracted for each module containing more than 10 members. Subsequently, their over-representation against a specified pathway database is evaluated relative to a selected background.
- **Segment IV:** three types of outputs are created:
    + **Circular diagrams:** the plots highlight the most important transcription factors and their connecting proteins in the full-size network are marked based on the module in which the proteins are found. *“Most important”* is defined by default as being in the top 30% of most central nodes sorted by the current-flow betweenness centrality. 
    + **Enriched pathways:** the top 3 pathways (based on FDR levels) for the first 5 modules (based on their size) are represented. Notably, there may be overlap among these pathways, and it is recommended that for publication purposes, a plot be recreated to emphasize unique pathways supported by strong biological rationales. 
    + **Summary report:** the report highlights the most important and robust nodes, pathways, transcription factors and kinases. All the definitions and the entire folder structure are presented in the summary report.

<img src="img/Overview.svg" width="100%">
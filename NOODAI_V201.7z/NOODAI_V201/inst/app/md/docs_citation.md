**How to cite**  
*Totu, Tiberiu; Riudavets Puig, Rafael; Häuser, Lukas Jonathan; Tomasoni, Mattia; Bolck, Hella Anna; Buljan, Marija.*  
**NOODAI**: *A webserver for network-oriented multi-omics data analysis and integration pipeline.*  
[https://doi.org/10.1101/2024.11.08.622488](https://doi.org/10.1101/2024.11.08.622488)

NOODAI version 2.0.0 relies on STRING v11.5, BioGRID v4.4.218, IntAct v245, Ensembl BioMart v114 and Reactome v90. Alternative knowledge databases can be provided by the user.

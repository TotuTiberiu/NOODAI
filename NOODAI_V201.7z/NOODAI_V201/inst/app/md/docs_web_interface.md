You can run your NOODAI analysis by navigating to the `Run NOODAI` tab on the side panel. There, the analysis is divided in three main panels:

- **Run the full pipeline:** this is the main tab where you can run the entire analysis pipeline with a few input parameters.
- **Custom algorithms:** in this tab, each segment of the analysis pipeline can be customized depending on the needs. Requires a thorough understanding of the analysis pipeline!
- **Results download:** in this tab you can download your analysis results using a unique identifier that was given to you after submitting an analysis request.
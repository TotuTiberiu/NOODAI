1. Upload your data as a **zipped folder** containing Excel files.
- Each Excel file should represent a **different omics layer**.  
- Create a different sheet within the file for each **condition comparison**.  
- Include a column with representative **UniProt IDs** (i.e. significant gene sets) or **ChEBI IDs**.  
- *Download the [Demo Dataset]() to understand formatting requirements, sheet names (compared conditions), and column names (containing UniProt or ChEBI IDs).*
2. In the **“Condition comparison (contrasts)”** field, specify the conditions you are comparing.
- Example: `DISEASEvsHEALTHY`  
- These must **match exactly** the sheet names in your Excel files.
3. Run the NOODAI pipeline. The default configuration performs a non-weighted MONET network analysis with STRING, BioGRID and IntAct knowledge-base interaction datasets, and REACTOME-based pathway analysis.
*Optionally, provide your email address to get notified when the results are ready.*
4. Save the shown **Results job ID**.
5. Go to the **NOODAI results page** and provide the Results ID. There you can follow the analysis progress and download the results when they are ready. When the analyses are complete you can choose conditions you wish to examine on the left "Selector" panel and then assess on the right the most central network elements together with connections among them visualised as a circos plot, as well as major pathways found enriched in the largest network modules. Information is also provided on the entities that constitute circos plots or individual modules.
6. By providing your email, you get notified when the analysis is complete and the result files can be easily downloaded from the link provided within the email. The results folder contains output Excel files that list centrality values for all analysed entities, provide information on the extracted network modules and describe biological roles of most central regulatory proteins (kinases and transcription factors). Please check the **"Results_Interpretation"** summary there!
---

 **Checklist: Was This Analysis Suitable for Your Data?**

Ask yourself the following:

- *Do most central entities point to biologically meaningful processes?*  
- *Are there modules with 10 or more members identified?*  
- *Are reported functional enrichments biologically meaningful?*  
- *Does network integration bring added value?*

*Note: Output files also include results for individual omics layers. For instance, higher average node betweenness value in the integrated analysis can point to a more structured architecture of the integrated network with a higher capacity for information flow centralized around key regulatory nodes.*
NOODAI relies mainly on protein-protein and small molecules interaction networks. Certain omics data, such as transcriptomics, can be utilized to construct such a network. However, some omics measurements are not inherently linked to proteins/small molecules, rendering a protein-protein interaction network purposeless (such as miRNAs). These should be mapped to either a ChEBI ID or UniProt ID.

Small molecule interactions are taken from IntAct. If you want other interaction source you should provide them as a custom made "Interaction File".

If you analyze other species that the pre-loaded ones you must provide all databases files and you can use the platform only for protein-protein interaction networks (due to ID conversion restrictions from BiomaRt).

**How to cite**  
*Totu, Tiberiu; Riudavets Puig, Rafael; Häuser, Lukas Jonathan; Tomasoni, Mattia; Bolck, Hella Anna; Buljan, Marija.*  
**NOODAI**: *A webserver for network-oriented multi-omics data analysis and integration pipeline.*  
[https://doi.org/10.1101/2024.11.08.622488](https://doi.org/10.1101/2024.11.08.622488)

NOODAI version 2.0.0 relies on STRING v11.5, BioGRID v4.4.218, IntAct v245, Ensembl BioMart v114 and Reactome v90. Alternative knowledge databases can be provided by the user.

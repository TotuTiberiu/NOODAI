Below we describe the required input parameters to be able to run NOODAI:

- **Condition comparison (contrasts):** as the analysis is based on the upregulated/downregulated elements when comparing one condition to another, such a comparison is termed here as a “contrast” (ex. the comparison of M1 to M2a has two contrasts: M1vsM2a contrast corresponding to the upregulated elements of M1 compared to M2a and M2avsM1 corresponding to the upregulated elements of M2a compared to M1). Each contrast should match an Excel sheet with an identical name in the tables from the uploaded ZIP archive. Please enter the contrasts separated by commas (ex: M1vsM2a,M2avsM1,M1vsM2c).
- **Omics files archive:** the web server accepts as input an archive that contains one Excel table for each of the omics profiles of interest. Each table should have at least one sheet, named after a unique analyzed contrast (ex: M1vsM2a) and should contain the upregulated elements of the first covariate compared to the second one (ex: the M1vsM2a sheet in the Proteomics.xlsx file contains the upregulated proteins found in M1 when compared to M2a considering a log2FC threshold of 1 and FDR threshold of 0.05). All sheets **MUST** have the column that contains the proteins/small molecules that are upregulated named UniProt_ChEBI. The names of the entries for this column **MUST** be UniProt or ChEBI Ids. All tables must contain the same number of sheets with the same names, even though they are empty! All sheets that are to be analyzed must contain the UniProt_ChEBI column.

Example of table format:

```
UniProt_ChEBI		Optional	Optional
P42224		        STAT1	        0.05
P40763		        STAT3	        0.05
```

#### Optional inputs (all have default values):

Besides the fields described in the `Mandatory input fields description` section, all fields are optional and will use default values when not specified. These fields are described below:

- **Weight factor:** if you want to analyze weighted interaction networks and have available weights for your input features, you can include an additional column named `Weight` in the Excel tables. This column should contain log fold changes or another relevant metric for your input features. This approach applies to any of the input omics layers or contrasts. In this case, edge weights will be computed using the NetWalk approach, and some centrality measures (excluding current-flow betweenness centrality) will incorporate these weights. The MONET decomposition tool will also take the edge weights into account. The weight parameter represents the NetWalk restart probability and should be a value greater than 0 but smaller than 1. By default it is set as 0.1.
- **MONET method:** the MONET method parameters must be specified following the MONET tool [instructions](https://github.com/BergmannLab/MONET). The format must remain as the one pre-loaded. The MONET avilable methods are: M1, K1 and R1. By default the networks are undirectional with a desired average degree for nodes in output of 10.
- **Pathway databases:** used to specify which pathway databases to use to find the over-represented pathways associated with each identified MONET module. Possible databases are `Reactome`, `Wikipathways`, `BioCarta`, `PID`, `NetPath`, `HumanCyc`, `INOH` and `SMPDB`. Note that licensing restrictions may apply to some databases, and you are responsible for compliance. The developers assume no liability in the event of a legal dispute. Currently, Reactome and Wikipathways are public domain licenses (CC0) and you can use them freely.
- **BioMart dataset:** the conversion of input Uniprot IDs to other identifiers is facilitated through the BioMart database service. The pre-selected dataset is the one corresponding to humans. If you are using data from other organisms, please provide the correct identifier. Some example identifiers are:
    + Mus musculus: `mmusculus_gene_ensembl`
    + Bos taurus: `btaurus_gene_ensembl`
    + Caenorhabditis elegans: `celegans_gene_ensembl`
    + Canis familiaris: `clfamiliaris_gene_ensembl`
    + Danio rerio: `drerio_gene_ensembl`
    + Drosophila melanogaster: `dmelanogaster_gene_ensembl`
    + Gallus gallus: `ggallus_gene_ensembl`
    + Rattus norvegicus: `rnorvegicus_gene_ensembl`
    + Saccharomyces cerevisiae: `scerevisiae_gene_ensembl`
    + Xenopus tropicalis: `xtropicalis_gene_ensembl`
    + Sus scrofa: `sscrofa_gene_ensembl`
    + Schizosaccharomyces pombe: `spombe_gene_ensembl`
If you have data from another organism than the pre-laoded ones described above, it is required to provide a pre-formatted interaction table, pathway, TF and kinome databases depending on the analysis segment you are interested in.
- **Interaction table file:** activating the **Add custom databases** button highlights the interaction databases fields that are dependent on the selection option for the Use `Pre-compiled Interaction file` field. Default protein-protein interaction databases are already loaded on the server. However, due to technical limitations all databases are already filtered to include only the selected species protein-protein and protein-small_molecule interactions. 
The pre-formatted interaction file that you can upload has the following format: 2 columns with the names Interactor1 and Interactor2, followed by lines with 2 proteins/small_molecule per line using NCBI or ChEBI IDs. It must be a tab-separated text file. YOU MUST provide this table if you have data from other organism than the selected ones. Formatting example:

    ```
    Interactor1	Interactor2
    10421	        23020
    10755	        4646
    ```
- **BioGrid database file:** one of the protein-protein interaction sources is the BioGrid database. The available version is 4.4.218 in mitab format filtered to include only entries with a confidence score. If you would like to upload another version you can upload it here. The database will be filtered automatically for humans!
- **STRING database file:** another protein-protein interaction database is STRING. The available version on the server is 11.5 containing the complete interactions data considering all sources and filtered to include only entries with a combined score above 0.7. This database is filtered a priori for the selected organisms interactions. If provided, this database will not be filtered. If you choose to provide this database, please make sure to filter it a priori for your organism of interest. Do not upload the entire database as it is too big.
- **IntAct database file:** the IntAct database is also used for the analysis. The psimitab from 13/07/2022 is already loaded and filtered to keep only interactions with a confidence score above 0.7 for the selected organisms. If you choose to upload another database, please filter it a priori.
- **Interaction table file:** the protein-protein interactions from BioGrid, STRING and IntAct databases filtered as above and the small molecule interactions from IntAct, are merged into a final pre-compiled interaction table.
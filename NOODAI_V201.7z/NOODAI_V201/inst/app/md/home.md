# Welcome to NOODAI!

The NOODAI software offers a method to collectively analyze multiple omics datasets by integrating them into a unified framework. As input, NOODAI takes the biological entities (i.e. genes/proteins/small molecules) found in at least one omics dataset comparing two conditions. In a nutshell, the analysis steps for each of the comparisons and omics dataset are:

1. Merging all genes/proteins/small molecules into a joint protein-protein and protein-small molecule interaction network.
2. Computing multiple centrality scores for each node, highlighting the most important proteins/small molecules. 
3. Decomposing the network into modules, where each module consists of upregulated or downregulated omics elements belonging to a specific signaling pathway. These subnetworks characterize a specific biological function, in their entirety defining the analyzed conditions.

<img src="img/Ribbon.svg" width="97%">



**How to cite**  
*Totu, Tiberiu; Riudavets Puig, Rafael; Häuser, Lukas Jonathan; Tomasoni, Mattia; Bolck, Hella Anna; Buljan, Marija.*  
**NOODAI**: *A webserver for network-oriented multi-omics data analysis and integration pipeline.*  
[https://doi.org/10.1101/2024.11.08.622488](https://doi.org/10.1101/2024.11.08.622488)
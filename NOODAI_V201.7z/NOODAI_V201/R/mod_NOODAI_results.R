working_dir = "/home/omics/NOODAI_shiny/"
setwd(working_dir)

draw_circos = function(data_tf, data_aux) {

  color_palette_members <- grDevices::colorRampPalette(
    c(
      "#7196BE",
      "#BD3737",
      "#CD9B1D",
      "#E8768F",
      "#855C5C",
      "#FFD2DC",
      "#663355",
      "#55CCAA",
      "#CFCF3F",
      "#99DAAF",
      "#CF73B8",
      "#E8890C",
      "#645ED4"
    )
  )

  color_palette_Group <- grDevices::colorRampPalette(RColorBrewer::brewer.pal(5, "Set1"))

  grid.col <- color_palette_members(length(unique(data_tf[, 4])))
  names(grid.col) <- gtools::mixedsort(as.character(unique(data_tf[, 4])), )

  vec_cols <- c(
    "#7196BE",
    "#BD3737",
    "#CD9B1D",
    "#E8768F",
    "#855C5C"
  )

  for (imk in 1:5) {
    if(length(which(names(grid.col)[imk] %in% as.character(c(1:5)))) > 0) {
      grid.col[imk]<-vec_cols[as.numeric(names(grid.col)[imk])]
    }
  }

  grid.col_aux <- grid.col
  grid.col <- sapply(
    data_tf[, 4],
    FUN = function(x) {
      grid.col[which(names(grid.col) %in% x)]
    }
  )

  names(grid.col) <- data_tf[, 1]

  aux <- as.character(
    data_aux[which(data_aux$Gene %in% data_tf$TF), 2]
  )
  names(aux) <- data_aux[which(data_aux$Gene %in% data_tf$TF), 1]

  grid.col <- c(
    grid.col_aux[match(aux,unique(names(grid.col_aux)))], grid.col[match(unique(names(grid.col)), names(grid.col))]
  )

  names(grid.col) <- c(names(aux),unique(data_tf[, 1]))

  data_circos <- data_tf[, c(1, 2, 3)]

  circlize::circos.clear()
  circlize::circos.par(start.degree = 180)
  circlize::circos.initialize(sectors = "a", xlim = c(0, length(unique(data_circos[, 1]))))

  graphics::par(cex = 1, mar = c(0, 0, 0, 0))
  circlize::chordDiagram(
    data_circos,
    transparency = 0.2,
    order = c(
      data_circos[, 1],
      sort((unique(data_circos[,2])), decreasing = TRUE)
    ),
    annotationTrack = c("name", "grid"),
    scale = TRUE,
    grid.col = grid.col,
    big.gap = 10,
    annotationTrackHeight = c(0.03, 0.03)
  )

  aaux1 <- unique(data_tf[, 4])
  aaux1 <- sort(aaux1)
  aaux2 <- grid.col_aux[unique(match(unique(data_tf[, 4]), unique(names(grid.col_aux))))]
  aaux2 <- aaux2[gtools::mixedsort(names(aaux2))]
  lgd_links = ComplexHeatmap::Legend(
    labels = aaux1,
    legend_gp = grid::gpar(fill = aaux2),
    title_position = "topleft",
    title = "Modules",
    labels_gp = grid::gpar(fontsize = 16),
    title_gp = grid::gpar(fontsize = 18, fontface = "bold")
  )

  ComplexHeatmap::draw(
    lgd_links,
    x = grid::unit(1, "npc") - grid::unit(7, "mm"),
    y = grid::unit(13, "mm"),
    just = c("right", "bottom")
  )

}

#' Draw enrichment Function
#'
#' @description Function to draw the enrichment plot given a data frame.
#'
#' @param df
#'
#' @noRd 
#'
#' @importFrom ggplot2 element_blank
draw_enrichment = function(df) {

  Pathway = log10_q_value = GeneRatio = Pathway_Hits_Cluster_Members = Module = NULL

  df = df %>%
    dplyr::rename(c(
      Pathway = "X1",
      log10_q_value = "X2",
      GeneRatio = "X3",
      Pathway_Hits_Cluster_Members = "X4",
      Module = "X5"
    ))
	
	
df$Pathway_truncated <- sapply(df$Pathway, function(x) {
  if (is.na(x)) return(NA_character_)
  x <- as.character(x)
  if (nchar(x) > 45) paste0(substr(x, 1, 45), "...") else x
}, USE.NAMES = FALSE)

df$Pathway_index <- factor(seq_len(nrow(df)), levels = rev(seq_len(nrow(df))))
df$Pathway_truncated <- rev(df$Pathway_truncated)


  ggplot2::ggplot(data = df, ggplot2::aes(x = Pathway_index, y = Pathway_Hits_Cluster_Members, fill = Module)) + 
    ggplot2::scale_fill_manual(
      values = c(
        "#7196BE",
        "#BD3737",
        "#CD9B1D",
        "#E8768F",
        "#855C5C"
      )
    ) +
    ggchicklet::geom_chicklet(radius = grid::unit(4, "mm"), width = 0.8) +
     ggplot2::scale_x_discrete(labels = df$Pathway_truncated) +
    ggplot2::coord_flip() +
    ggplot2::ylab("Pathway Hits/Cluster Members") +
    ggplot2::xlab("") +
    ggplot2::guides(fill = ggplot2::guide_legend(title = "Modules:")) +
    ggplot2::theme(
      axis.title = ggplot2::element_text(
        color="black",
        size = 15,
        hjust = 0.5,
        vjust = 1
      ),
      axis.line = ggplot2::element_line(
        size = 1,
        colour = "black"
      ),
      axis.text.x = ggplot2::element_text(
        color = "black",
        size = 13
      ),
      axis.text.y = ggplot2::element_text(
        color = "black",
        size = 13
      ),
      plot.title = ggplot2::element_text(
        color = "black",
        face = 'bold.italic',
        size = 15,
        hjust = 0,
        vjust = 1
      ),
      panel.background = ggplot2::element_blank(),
      axis.line.y = ggplot2::element_blank(),
      legend.title = ggplot2::element_text(
        color = "black",
        size = 14,
        face = "bold"
      ),
      legend.text = ggplot2::element_text(
        color = "black",
        size = 14
      ),
      legend.key = ggplot2::element_rect(fill = "whitesmoke"),
      legend.background = element_blank(),
      legend.text.align = 0.5,
	  legend.position = "top"
    )

}

# Cytoscape-related functions

drawSVG = function(NOODAI_object, selected_contrast, selected_module, is_legend = F) {

  if (is_legend == F) {
    svg_path = NOODAI_object@cytoscape_modules[[selected_contrast]][grepl(paste0(selected_module, "_"), NOODAI_object@cytoscape_modules[[selected_contrast]])]
  } else {
    svg_path = NOODAI_object@cytoscape_modules[[selected_contrast]][grepl("Legend_cytoscape.svg", NOODAI_object@cytoscape_modules[[selected_contrast]], fixed = T)]
  }
  
      
  img = magick::image_read(svg_path, density = 200)
  magick::image_ggplot(img)

}

get_svg_path = function(NOODAI_object, selected_contrast, selected_module, is_legend = F) {

 paths <- NOODAI_object@cytoscape_modules[[selected_contrast]]
  
  if (is_legend == FALSE) {
    matches <- paths[grepl(paste0(selected_module, "_"), paths)]
  } else {
    matches <- paths[grepl("Legend_cytoscape.svg", paths, fixed = TRUE)]
  }

  # If multiple matches, pick the first
  if (length(matches) > 1) {
    warning("Multiple matching SVG paths found. Using the first one.")
  }

  return(matches[1])

  return(svg_path)

}

#Get the available cytoscape modules

# Get the available modules for a selected contrast
get_contrast_modules <- function(NOODAI_object, contrast) {

  svg_files = basename(NOODAI_object@cytoscape_modules[[contrast]])
  svg_files = svg_files[!grepl("Legend", svg_files)]

  modules = gsub(
    paste0("_", contrast,"_",NOODAI_object@Results_index, ".svg"),
    "",
    svg_files
  )
  
  return(modules)

}


library(shinydashboard)
library(circlize)
library(magick)
library(shinyjs)

#' NOODAI_results UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd 
#'
#' @importFrom shiny NS tagList 
mod_NOODAI_results_ui <- function(id) {
  ns <- NS(id)
  tagList(shinyjs::useShinyjs(),
    shiny::fluidRow(
      shinydashboard::box(
        status = "success",
        width = 3,
        title = "Fetch your results",
        textInput(
          ns("results_id"),
          label = "Results directory index",
          value = ""
        ),
         fluidRow(
    column(
      width = 8,
      actionButton(
        inputId = ns("submit_results_dir"),
        label = shiny::span(
          shiny::tagList(
            tags$span("Check job status"),
            tags$span(shiny::icon("info-circle"))
          )
        ),
        width = "100%"
      ) %>% spsComps::bsTooltip(
        "Fetch results for a directory index",
        "right"
      )
    ),
    column(
      width = 4,
      downloadButton(
        outputId = ns("downloadData"),
        label = NULL,
        class = "btn-sm btn-success",
        style = "margin-top: 4px; width: 100%;"
      )
    )
  )
      ),
      shinydashboard::box(
        status = "success",
        width = 9,
        title = "Job status",
        shinyWidgets::progressBar(
          id = ns("progress_bar"),
          value = 0
        ),
        shiny::textOutput(
          ns("current_status")
        )
      ),
    ),
    shiny::fluidRow(
      shinydashboard::box(
        status = "success",
        width = 3,
        title = "Selector",
        selectInput(
          ns("contrast_selector"),
          label = "Select condition",
          choices = c("NONE")
        ),
		div(
		id = "module_selector_wrapper",
         selectInput(
           ns("module_selector"),
           label = "Select module",
           choices = c("NONE")
         )
		 )
      ),
      shinydashboard::tabBox(
	  id = "main_tabs",
        width = 9,
        title = "",
        tabPanel(
          title = "Circos plot",
          plotOutput(ns("circos")),
        ),
        tabPanel(
          title = "Circos plot data table",
          DT::DTOutput(ns("circos_data_table"))
        ),
        tabPanel(
          title = "Pathway enrichment",
          plotOutput(ns("pathway_enrichment"))
        ),
        tabPanel(
          title = "Pathway enrichment data table",
          DT::DTOutput(ns("enrichment_data_table"))
        ),
        tabPanel(
          title = "Module table",
          DT::DTOutput(ns("module_data_table"))
        ),
		
		
		#For Cytoscape
        # tabPanel(
        #   title = "Module Viewer",
        #   shiny::fluidRow(
        #     shiny::column(
        #       width = 9,
        #       imageOutput(ns("module_svg_image"))
        #     ),
        #     shiny::column(
        #       width = 3,
        #       imageOutput(ns("module_svg_legend"))
        #     )
        #   )
        # )
		
		tabPanel(
			title = "Module Viewer",
			value = "cyto_tab",
			uiOutput(ns("module_viewer_content"))
		)
		#uiOutput(ns("module_viewer_tab"))
		
		#End for cytoscape
      )
    )
  )
}
    
#' NOODAI_results server Function
#'
#' @description The server part of the results module.
#'
#' @param input,output,session Internal parameters for {shiny}.
#'
#' @noRd 
mod_NOODAI_results_server <- function(id, main_session) {
 
 moduleServer(id, function(input, output, session) {
 
ns <- session$ns

  session$onFlushed(function() {
    hideTab(inputId = "main_tabs", target = "cyto_tab")
  }, once = TRUE)


observeEvent(results_dir(), {
  folder_path <- file.path(working_dir, results_dir(), "MONET_analysis/MONET/Cytoscape_Networks/")
  cat("Checking folder:", folder_path, "\n")
  session$onFlushed(function() {
    if (dir.exists(folder_path)) {
      showTab(inputId = "main_tabs", target = "cyto_tab", select = TRUE)
      cat("Showing cyto_tab\n")
    } else {
      hideTab(inputId = "main_tabs", target = "cyto_tab")
      cat("Hiding cyto_tab\n")
    }
  })
})

session$onFlushed(function() {
  shinyjs::hide(id = "module_selector_wrapper")
}, once = TRUE)

observeEvent(results_dir(), {
  folder_path <- file.path(working_dir, results_dir(), "MONET_analysis/MONET/Cytoscape_Networks/")
  cat("Checking folder:", folder_path, "\n")
  session$onFlushed(function() {
    if (dir.exists(folder_path)) {
      shinyjs::show(id = "module_selector_wrapper")
      cat("Showing module_selector\n")
    } else {
      shinyjs::hide(id = "module_selector_wrapper")
      cat("Hiding module_selector\n")
    }
  })
})


  results_dir = reactive({
    out_dir = paste0("Results_", input$results_id)
    return(out_dir)
  })
  
  NOODAI_object_2 = eventReactive(input$submit_results_dir, {
    
    NOODAI_obj_path = file.path(
      working_dir,
      results_dir(),
      "NOODAI_object.RDS"
    )
    if (file.exists(NOODAI_obj_path)) {
      obj = readRDS(
        file.path(
          working_dir,
          results_dir(),
          "NOODAI_object.RDS"
        )
      )
      return(obj)
    } else {
      return(NA)
    }

  })

  observe({
    NOODAI_object_2()
    if (!is(NOODAI_object_2(), "NOODAI")) {
      shinyWidgets::updateProgressBar(
        session = session,
        id = "progress_bar",
        value = 0
      )
    } else {
      if (NOODAI_object_2()@status == "Network analysis") {
        shinyWidgets::updateProgressBar(
          session = session,
          id = "progress_bar",
          value = 20
        )
      } else if (NOODAI_object_2()@status == "MONET analysis") {
        shinyWidgets::updateProgressBar(
          session = session,
          id = "progress_bar",
          value = 40
        )
      } else if (NOODAI_object_2()@status == "MONET pathway extraction") {
        shinyWidgets::updateProgressBar(
          session = session,
          id = "progress_bar",
          value = 60
        )
      } else if (NOODAI_object_2()@status == "Plot and report generation") {
        shinyWidgets::updateProgressBar(
          session = session,
          id = "progress_bar",
          value = 80
        )
      } else if (NOODAI_object_2()@status == "Finished") {
        shinyWidgets::updateProgressBar(
          session = session,
          id = "progress_bar",
          value = 100
        )
      } 
      updateSelectInput(session, "contrast_selector", choices = NOODAI_object_2()@phenotype_comparison)
    }
  })

  output$current_status = renderText({
    if (!is(NOODAI_object_2(), "NOODAI")) {
      return("Current status: to start")
    } else {
      return(paste0("Current status: ", NOODAI_object_2()@status))
    }
  })

  output$circos = renderPlot({
    tryCatch(
      {draw_circos(NOODAI_object_2()@circos[[input$contrast_selector]], NOODAI_object_2()@circos_aux[[input$contrast_selector]])},
      error = function(e) {""}
    )
  })

  output$pathway_enrichment = renderPlot({
    tryCatch(
      {draw_enrichment(NOODAI_object_2()@pathways[[input$contrast_selector]])},
      error = function(e) {""}
    )
  })

  output$circos_data_table = DT::renderDataTable(
    NOODAI_object_2()@circos[[input$contrast_selector]][, c("Protein", "TF", "SubModule")],
    options = list(lengthChange = FALSE),
    rownames = FALSE
  )

  output$enrichment_data_table = DT::renderDataTable(
    NOODAI_object_2()@pathways[[input$contrast_selector]] %>%
      dplyr::rename(c(
        Pathway = "X1",
        log10_q_value = "X2",
        GeneRatio = "X3",
        Pathway_Hits_Cluster_Members = "X4",
        Module = "X5"
      )),
    options = list(lengthChange = FALSE),
    rownames = FALSE
  )

  output$module_data_table = DT::renderDataTable(
    NOODAI_object_2()@circos_aux[[input$contrast_selector]][, c("Gene", "SumModule")] %>%
      dplyr::arrange(SumModule) %>% 
      dplyr::rename(SubModule = "SumModule"),
    options = list(lengthChange = FALSE),
    rownames = FALSE
  )


#Start cytoscape part

has_module_images <- reactive({
  req(NOODAI_object_2(), input$contrast_selector, input$module_selector)
  
  tryCatch({
    svg_path <- get_svg_path(NOODAI_object_2(), input$contrast_selector, input$module_selector)
    legend_path <- get_svg_path(NOODAI_object_2(), input$contrast_selector, input$module_selector, is_legend = TRUE)
    
    svg_exists <- !is.null(svg_path) && length(svg_path) > 0 && file.exists(svg_path)
    legend_exists <- !is.null(legend_path) && length(legend_path) > 0 && file.exists(legend_path)

    svg_exists && legend_exists
  }, error = function(e) {
    FALSE
  })
})

output$module_viewer_content <- renderUI({
  if (isTRUE(has_module_images())) {
    shiny::fluidRow(
      shiny::column(
        width = 9,
        imageOutput(ns("module_svg_image"))
      ),
      shiny::column(
        width = 3,
        imageOutput(ns("module_svg_legend"))
      )
    )
  } else {
    shiny::fluidRow(
      column(
        width = 12,
        tags$div(
          style = "text-align: center; margin-top: 50px; font-size: 16px; font-weight: bold;",
          "There are no Cytoscape modules to be shown. Please run the analysis with the \"Draw networks\" parameter enabled."
        )
      )
    )
  }
})

   observe({
     selected_contrast <- input$contrast_selector
     tryCatch({
       if (selected_contrast != "NONE") {
         available_modules = get_contrast_modules(
           NOODAI_object_2(),
           selected_contrast
         )
         updateSelectInput(session, "module_selector", choices = available_modules)
     }
   }, error = function(e) {
     ""
   })
   })

   output$module_svg_image <- renderImage({
     tryCatch({
       svg_path = get_svg_path(NOODAI_object_2(), input$contrast_selector, input$module_selector)

       list(
         src = svg_path,
         contentType = 'image/svg+xml',
         width = "100%",
         height = "100%",
         alt = "Network module"
       )
     }, error = function(e) {"Nothing to plot"})
   },deleteFile = FALSE)

   output$module_svg_legend <- renderImage({
     tryCatch({

       svg_path = get_svg_path(NOODAI_object_2(), input$contrast_selector, input$module_selector, is_legend = T)

       list(
         src = svg_path,
         contentType = 'image/svg+xml',
         width = "100%",
         height = "100%",
         alt = "Legend"
       )
     }, error = function(e) {list(src = NULL)})
   },deleteFile = FALSE)
  
  #End cytoscape part
  
  #Download the results
  
        observe({
        
        useReactiveDownload <- function(input, output, session, df){
          downloadHandler(
            filename = function() {
              paste0("Results_",Sys.Date(),".zip")
            },
            content = function(file) {
              ns <- paste0(working_dir,"/Results_",df,"/ResultsZip.zip")
              print(ns)
              file.copy(ns, file)
            },
            contentType = "application/zip"
          )
        }
        output$downloadData <- useReactiveDownload(input, output, session, df = NOODAI_object_2()@Results_index)
        
      })
  
  
  
  
  })
  
}

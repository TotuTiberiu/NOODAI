#' docs UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd 
#'
#' @importFrom shiny NS tagList 
mod_docs_ui <- function(id) {
  ns <- NS(id)
  tagList(
    shiny::fluidRow(
      shiny::column(
        width = 12,
        shinydashboard::box(
          width = 12,
          status = "success",
          title = tagList(shiny::icon("rocket"), "Getting started"),
          shiny::includeMarkdown(app_sys("app/md/docs_getting_started.md"))
        ),
		shinydashboard::box(
          width = 12,
          status = "success",
          title = tagList(shiny::icon("book"), "Overview"),
          shiny::includeMarkdown(app_sys("app/md/docs_overview.md"))
        ),
        shinydashboard::box(
          width = 12,
          status = "success",
          title = tagList(shiny::icon("window-maximize"), "Web interface"),
          shiny::includeMarkdown(app_sys("app/md/docs_web_interface.md"))
        ),
        shinydashboard::box(
          width = 12,
          status = "success",
          title = tagList(shiny::icon("file"), "Input description"),
          shiny::includeMarkdown(app_sys("app/md/docs_inputs.md"))
        ),
        shinydashboard::box(
          width = 12,
          status = "success",
          title = tagList(shiny::icon("gears"), "Running the pipeline with the demo dataset"),
          shiny::includeMarkdown(app_sys("app/md/docs_demo.md"))
        ),
        shinydashboard::box(
          width = 12,
          status = "success",
          title = tagList(shiny::icon("file"), "Analysis submission and results download tab"),
          shiny::includeMarkdown(app_sys("app/md/docs_results.md"))
        ),
        shinydashboard::box(
          width = 12,
          status = "success",
          title = tagList(shiny::icon("gear"), "Custom algorithms tab"),
          shiny::includeMarkdown(app_sys("app/md/docs_custom_algorithms.md"))
        ),
        shinydashboard::box(
          width = 12,
          status = "success",
          title = tagList(shiny::icon("book"), "Miscellanous"),
          shiny::includeMarkdown(app_sys("app/md/docs_misc.md"))
        )
      )
    )
  )
}
    
#' docs Server Functions
#'
#' @noRd 
mod_docs_server <- function(id){
  moduleServer(id, function(input, output, session){
    ns <- session$ns
 
  })
}
    
## To be copied in the UI
# mod_docs_ui("docs_1")
    
## To be copied in the server
# mod_docs_server("docs_1")

## Header elements for the visualization
header <- shinydashboard::dashboardHeader(
  title = "NOODAI",
  titleWidth = 215
)


## Sidebar elements for the search visualizations
sidebar <- shinydashboard::dashboardSidebar(
  width = 215,
  shinydashboard::sidebarMenu(
    id = "tabs",
    style = "position: fixed; overflow: visible;width: 200px;",
    shinydashboard::menuItem(
      "Home",
      tabName = "home",
      icon = shiny::icon("home")
    ),
    shinydashboard::menuItem(
      "Run NOODAI",
      tabName = "NOODAI_pipeline",
      icon = shiny::icon("cogs")
    ),
    shinydashboard::menuItem(
      "Documentation",
      tabName = "NOODAI_docs",
      icon = shiny::icon("book")
    ),
    shinydashboard::menuItem(
      "Results",
      tabName = "results",
      icon = shiny::icon("chart-bar")
    )
  )
)

footer <- shinydashboardPlus::dashboardFooter(
  left = shiny::fluidRow(
    shiny::column(
      width = 2,
      shiny::img(
        src = "www/empa.png",
        width = 200,
        id = "logo"
      )
    ),
    shiny::column(
	offset=2,
      width = 8,
      shiny::p(
        "The analysis pipeline is provided for use 'as is' and 'as available' under GNU GPL v3, see <https://www.gnu.org/licenses/>. The authors make no representations or warranties of any kind, expressed or implied, regarding the performance, reliability, or suitability of the analysis.\n By using this website, you agree that the authors shall not be responsible for any data loss, corruption, or unauthorized access to your data. It is your responsibility to implement appropriate backup and security measures to safeguard your data. NOODAI Copyright (C) 2025, Empa, Tiberiu Totu, Rafael Riudavets Puig.", 
        style = "font-size:11px; text-align:justify"
      )
    )
  )
)

js <- "
$(function () {
  $('[data-toggle=tooltip]').tooltip()
})
"

#' The application User-Interface
#'
#' @param request Internal parameter for `{shiny}`.
#'     DO NOT REMOVE.
#' @import shiny
#' @noRd
app_ui <- function(request) {
  tagList(
    # Leave this function for adding external resources
    golem_add_external_resources(),
    # Your application UI logic
    tagList(
      tags$head(
        tags$script(HTML(js))
      ),
      shinydashboardPlus::dashboardPage(
        header = header,
        sidebar = sidebar,
        footer = footer,
        body = shinydashboard::dashboardBody(
          shinydashboard::tabItems(
            shinydashboard::tabItem(
              tabName = "home",
              mod_home_ui("home_1")
            ),
            shinydashboard::tabItem(
              tabName = "NOODAI_pipeline",
              mod_NOODAI_pipeline_ui("NOODAI_pipeline_1")
            ),
            shinydashboard::tabItem(
              tabName = "NOODAI_docs",
              mod_docs_ui("NOODAI_docs")
            ),
            shinydashboard::tabItem(
              tabName = "results",
              mod_NOODAI_results_ui("NOODAI_results_1")
            )
          )
        )
      )
    )
  )
}

#' Add external Resources to the Application
#'
#' This function is internally used to add external
#' resources inside the Shiny application.
#'
#' @import shiny
#' @importFrom golem add_resource_path activate_js favicon bundle_resources
#' @noRd
golem_add_external_resources <- function() {
  add_resource_path(
    "www",
    app_sys("app/www")
  )

  add_resource_path(
    "img",
    app_sys("app/img")
  )

  add_resource_path(
    "md",
    app_sys("app/md")
  )

  shiny::tags$head(
    golem::favicon(ext = "png"),
    golem::bundle_resources(
      path = app_sys("app/www"),
      app_title = "omicsoracle"
    ),
    golem::bundle_resources(
      path = app_sys("app/img"),
      app_title = "omicsoracle"
    ),
    golem::bundle_resources(
      path = app_sys("app/md"),
      app_title = "omicsoracle"
    )
    # Add here other external resources
    # for example, you can add shinyalert::useShinyalert()
  )
}

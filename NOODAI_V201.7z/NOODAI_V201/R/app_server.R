#' The application server-side
#'
#' @param input,output,session Internal parameters for {shiny}.
#'     DO NOT REMOVE.
#' @import shiny
#' @noRd
app_server <- function(input, output, session) {
  launch_NOODAI <- shiny::reactiveValues(dt = NULL, flag = NULL)
  # Your application server logic
  # shiny::callModule(
  #   mod_NOODAI_pipeline_server,
  #   id = "NOODAI_pipeline_1",
  #   session = session
  # )
  mod_NOODAI_pipeline_server(id = "NOODAI_pipeline_1", main_session = session)
  mod_NOODAI_results_server(id = "NOODAI_results_1", main_session = session)
  # shiny::callModule(
  #   mod_NOODAI_results_server,
  #   id = "NOODAI_results_1"
  # )

}

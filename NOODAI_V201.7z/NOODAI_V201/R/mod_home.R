#' home UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd 
#'
#' @importFrom shiny NS tagList 
mod_home_ui <- function(id) {
  ns <- NS(id)
  tagList(
   tags$head(
      tags$style(HTML("
        .no-overflow {
          max-width: 100%;
          margin: 0 auto;
          overflow-x: hidden;
        }
        .no-overflow img {
          max-width: 100% !important;
          height: auto;
          display: block;
          margin-left: auto;
          margin-right: auto;
        }
      "))
    ),
      div(
      class = "no-overflow",
    shiny::fluidRow(
      shiny::fluidRow(
        shiny::div(
          shiny::img(
            src = "www/omicsoracle.png",
            width = 100, id = "logo"
          ),
          style = "text-align:center;"
        )
      ),
      shiny::column(
        width = 12,
        shiny::fluidRow(
          shinydashboard::box(
            width = 12,
            status = "success",
            shiny::includeMarkdown(app_sys("app/md/home.md"))
          )
        )
      )
    )
  )
  )
}
    
#' home Server Functions
#'
#' @noRd 
mod_home_server <- function(id){
    moduleServer(id, function(input, output, session){
    ns <- session$ns
 
  })
}
    
## To be copied in the UI
# mod_home_ui("home_1")
    
## To be copied in the server
# mod_home_server("home_1")
